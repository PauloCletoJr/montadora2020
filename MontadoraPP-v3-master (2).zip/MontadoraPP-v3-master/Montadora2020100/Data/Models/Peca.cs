﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Montadora2020100.Models
{
    public class Peca
    {
        public int ID { get; set; }
        [Display(Name = "Nome")]
        public string Nome_Peca { get; set; }
        [Display(Name = "Descrição")]
        public string Descricao_Peca { get; set; }
        [Display(Name = "Valor do Produto")]
        public string Valor_peca { get; set; }
        [Display(Name = "Fornecedor")]
        public string Fornecedor_Peca { get; set; }
    }
}
