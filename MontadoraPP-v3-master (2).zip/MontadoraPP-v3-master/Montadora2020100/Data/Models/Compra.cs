﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Montadora2020100.Models
{
    public class Compra
    {
        public int ID { get; set; }
        [Display(Name = "Funcionário")]
        public string Funcionario_Compra { get; set; }
        [Display(Name = "Fornecedor")]
        public string Fornecedor_Compra { get; set; }
        [Display(Name = "Peça")]
        public string Peca_Compra { get; set; }
        [Display(Name = "Quantidade")]
        public int Quantidade_Compra { get; set; }
        [Display(Name = "Valor")]
        [Column(TypeName = "decimal(18, 2)")]
        public decimal ValorUnit_Compra { get; set; }
        [Display(Name = "Total")]
        public decimal ValorTotal_Compra { get; set; }
    }
}
