﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Montadora2020100.Models
{
    public class Venda
    {
        [Display(Name = "Nº do Pedido")]
        public int ID { get; set; }
        [Display(Name = "Vendedor")]
        public string Vendedor_Venda { get; set; }
        [Display(Name = "Cliente")]
        public string Cliente_Venda { get; set; }
        [Display(Name = "Peça")]
        public string Peca_Venda { get; set; }
        [Display(Name = "Quantidade")]
        public string Quantidade_Venda { get; set; }
        [Display(Name = "Valor Unitário")]
        public string ValorUnit_Venda { get; set; }
        [Display(Name = "Valor Total")]
        public string ValorFinal_Venda { get; set; }
        [Display(Name = "CEP")]
        public string CEPEntrega_Venda { get; set; }
        [Display(Name = "Rua")]
        public string RuaEntrega_Venda { get; set; }
        [Display(Name = "Bairro")]
        public string BairroEntrega_Venda { get; set; }
        [Display(Name = "Cidade")]
        public string CidadeEntrega_Venda { get; set; }
        [Display(Name = "Estado")]
        public string EstadoEntrega_Venda { get; set; }
        [Display(Name = "País")]
        public string PaisEntrega_Venda { get; set; }
    }
}
