﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Montadora2020100.Models;

namespace Montadora2020100.Data
{
    public class Montadora2020100Context : DbContext
    {
        public Montadora2020100Context (DbContextOptions<Montadora2020100Context> options)
            : base(options)
        {
        }

        public DbSet<Montadora2020100.Models.Cliente> Cliente { get; set; }
    }
}
