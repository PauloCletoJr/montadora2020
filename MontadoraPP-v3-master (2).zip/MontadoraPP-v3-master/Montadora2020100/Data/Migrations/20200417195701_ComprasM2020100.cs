﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Montadora2020100.Data.Migrations
{
    public partial class ComprasM2020100 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Compra",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Funcionario_Compra = table.Column<string>(nullable: true),
                    Fornecedor_Compra = table.Column<string>(nullable: true),
                    Peca_Compra = table.Column<string>(nullable: true),
                    Quantidade_Compra = table.Column<string>(nullable: true),
                    ValorUnit_Compra = table.Column<string>(nullable: true),
                    ValorTotal_Compra = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Compra", x => x.ID);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Compra");
        }
    }
}
