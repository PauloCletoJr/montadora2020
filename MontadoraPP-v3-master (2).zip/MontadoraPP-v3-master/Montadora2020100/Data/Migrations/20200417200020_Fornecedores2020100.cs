﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Montadora2020100.Data.Migrations
{
    public partial class Fornecedores2020100 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Fornecedor",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nome_Fornecedor = table.Column<string>(nullable: true),
                    CNPJ_Fornecedor = table.Column<string>(nullable: true),
                    Contato_Fornecedor = table.Column<string>(nullable: true),
                    Contatodois_Fornecedor = table.Column<string>(nullable: true),
                    Email_Fornecedor = table.Column<string>(nullable: true),
                    Descricao_Fornecedor = table.Column<string>(nullable: true),
                    CEP_Fornecedor = table.Column<string>(nullable: true),
                    Rua_Fornecedor = table.Column<string>(nullable: true),
                    Bairro_Fornecedor = table.Column<string>(nullable: true),
                    Cidade_Fornecedor = table.Column<string>(nullable: true),
                    Estado_Fornecedor = table.Column<string>(nullable: true),
                    Pais_Fornecedor = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Fornecedor", x => x.ID);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Fornecedor");
        }
    }
}
