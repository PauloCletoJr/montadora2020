﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Montadora2020100.Data.Migrations
{
    public partial class VendasM2020100 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Venda",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Vendedor_Venda = table.Column<string>(nullable: true),
                    Cliente_Venda = table.Column<string>(nullable: true),
                    Peca_Venda = table.Column<string>(nullable: true),
                    Quantidade_Venda = table.Column<string>(nullable: true),
                    ValorUnit_Venda = table.Column<string>(nullable: true),
                    ValorFinal_Venda = table.Column<string>(nullable: true),
                    CEPEntrega_Venda = table.Column<string>(nullable: true),
                    RuaEntrega_Venda = table.Column<string>(nullable: true),
                    BairroEntrega_Venda = table.Column<string>(nullable: true),
                    CidadeEntrega_Venda = table.Column<string>(nullable: true),
                    EstadoEntrega_Venda = table.Column<string>(nullable: true),
                    PaisEntrega_Venda = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Venda", x => x.ID);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Venda");
        }
    }
}
