﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Montadora2020100.Data.Migrations
{
    public partial class PecasM2020100 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Peca",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nome_Peca = table.Column<string>(nullable: true),
                    Descricao_Peca = table.Column<string>(nullable: true),
                    Valor_peca = table.Column<string>(nullable: true),
                    Fornecedor_Peca = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Peca", x => x.ID);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Peca");
        }
    }
}
