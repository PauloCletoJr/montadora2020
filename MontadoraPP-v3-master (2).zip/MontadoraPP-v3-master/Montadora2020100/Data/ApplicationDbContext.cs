﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Montadora2020100.Models;

namespace Montadora2020100.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<Montadora2020100.Models.Cliente> Cliente { get; set; }
        public DbSet<Montadora2020100.Models.Compra> Compra { get; set; }
        public DbSet<Montadora2020100.Models.Fornecedor> Fornecedor { get; set; }
        public DbSet<Montadora2020100.Models.Funcionario> Funcionario { get; set; }
        public DbSet<Montadora2020100.Models.Peca> Peca { get; set; }
        public DbSet<Montadora2020100.Models.Venda> Venda { get; set; }
    }
}
