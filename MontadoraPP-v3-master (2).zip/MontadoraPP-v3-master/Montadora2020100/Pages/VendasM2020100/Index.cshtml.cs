﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Montadora2020100.Data;
using Montadora2020100.Models;

namespace Montadora2020100.Pages.VendasM2020100
{
    public class IndexModel : PageModel
    {
        private readonly Montadora2020100.Data.ApplicationDbContext _context;

        public IndexModel(Montadora2020100.Data.ApplicationDbContext context)
        {
            _context = context;
        }

        public IList<Venda> Venda { get;set; }

        public async Task OnGetAsync()
        {
            Venda = await _context.Venda.ToListAsync();
        }
    }
}
