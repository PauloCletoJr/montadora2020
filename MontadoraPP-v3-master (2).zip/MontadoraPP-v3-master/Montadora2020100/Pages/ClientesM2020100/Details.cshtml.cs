﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Montadora2020100.Data;
using Montadora2020100.Models;

namespace Montadora2020100.Pages.ClientesM2020100
{
    public class DetailsModel : PageModel
    {
        private readonly Montadora2020100.Data.ApplicationDbContext _context;

        public DetailsModel(Montadora2020100.Data.ApplicationDbContext context)
        {
            _context = context;
        }

        public Cliente Cliente { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Cliente = await _context.Cliente.FirstOrDefaultAsync(m => m.ID == id);

            if (Cliente == null)
            {
                return NotFound();
            }
            return Page();
        }
    }
}
